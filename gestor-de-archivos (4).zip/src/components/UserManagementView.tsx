import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  UserPlus,
  Trash2,
  Users,
  Key,
  Shield,
  UserCheck,
  AlertCircle,
  X,
  CheckCircle2,
  RefreshCw
} from "lucide-react";
import { User } from "../types";
import { safeJson } from "../utils";

interface UserManagementProps {
  currentUser: User;
}

export default function UserManagementView({ currentUser }: UserManagementProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form State
  const [newUsername, setNewUsername] = useState("");
  const [newPin, setNewPin] = useState("");
  const [newRole, setNewRole] = useState<"admin" | "user">("user");
  const [formSuccess, setFormSuccess] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [formLoading, setFormLoading] = useState(false);

  // Custom User Deletion Confirmation State
  const [deleteUserConfirm, setDeleteUserConfirm] = useState<{ id: string; username: string } | null>(null);

  // Fetch users
  const fetchUsers = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/auth/users?username=${encodeURIComponent(currentUser.username)}`);
      const data = await safeJson(res);
      if (!res.ok) {
        throw new Error(data.error || "No se pudo cargar la lista de usuarios.");
      }
      setUsers(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [currentUser]);

  // Handle User Creation
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim() || !newPin.trim()) {
      setFormError("Por favor, rellene todos los campos.");
      return;
    }

    setFormError(null);
    setFormSuccess(null);
    setFormLoading(true);

    try {
      const res = await fetch("/api/auth/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adminUsername: currentUser.username,
          newUsername: newUsername.trim(),
          pin: newPin.trim(),
          role: newRole,
        }),
      });

      const data = await safeJson(res);
      if (!res.ok) {
        throw new Error(data.error || "Error al crear el usuario.");
      }

      setFormSuccess(`¡Cuenta creada con éxito para ${newUsername.trim()}!`);
      setNewUsername("");
      setNewPin("");
      setNewRole("user");
      fetchUsers();
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setFormLoading(false);
    }
  };

  // Handle User Deletion Trigger
  const handleDeleteUserClick = (userId: string, targetName: string) => {
    if (targetName === "Frida29" || targetName === "Fida29") {
      alert("No se puede eliminar al administrador principal del sistema.");
      return;
    }
    setDeleteUserConfirm({ id: userId, username: targetName });
  };

  const executeDeleteUser = async () => {
    if (!deleteUserConfirm) return;
    const { id, username } = deleteUserConfirm;
    setDeleteUserConfirm(null);

    try {
      const res = await fetch(`/api/auth/users/${id}?username=${encodeURIComponent(currentUser.username)}`, {
        method: "DELETE",
      });

      const data = await safeJson(res);
      if (!res.ok) {
        throw new Error(data.error || "Error al eliminar usuario.");
      }

      fetchUsers();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 md:p-8 font-sans bg-slate-50 text-slate-900 selection:bg-blue-600 selection:text-white">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-800">
            Control de Usuarios
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Gestione y cree cuentas autorizadas para acceder al portal de sincronización.
          </p>
        </div>
        <button
          onClick={fetchUsers}
          className="flex items-center gap-2 text-xs font-semibold bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 py-2 px-4 rounded-lg transition-colors shadow-sm self-start md:self-auto"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Actualizar Lista</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Create User Form */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm h-fit">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-sm">Nueva Cuenta</h3>
              <p className="text-xs text-slate-400">Añada otro miembro al sistema</p>
            </div>
          </div>

          <form onSubmit={handleCreateUser} className="space-y-4">
            {formError && (
              <div className="p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-lg text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                <span>{formError}</span>
              </div>
            )}

            {formSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-700 rounded-lg text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>{formSuccess}</span>
              </div>
            )}

            {/* Username */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                Nombre de Usuario
              </label>
              <input
                type="text"
                placeholder="Ej. Juan Pérez"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white rounded-lg text-sm transition-all outline-none focus:ring-1 focus:ring-blue-600"
              />
            </div>

            {/* Password/PIN */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                Contraseña / PIN
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Key className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  placeholder="Ej. 1234 o pin seguro"
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white rounded-lg text-sm transition-all outline-none font-mono focus:ring-1 focus:ring-blue-600"
                />
              </div>
            </div>

            {/* Role selection */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                Rol de Cuenta
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setNewRole("user")}
                  className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    newRole === "user"
                      ? "border-blue-600 bg-blue-50 text-blue-700 shadow-sm shadow-blue-100"
                      : "border-slate-250 bg-white text-slate-500 hover:bg-slate-50"
                  }`}
                >
                  <UserCheck className="w-4 h-4" />
                  Usuario
                </button>
                <button
                  type="button"
                  onClick={() => setNewRole("admin")}
                  className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    newRole === "admin"
                      ? "border-blue-600 bg-blue-50 text-blue-700 shadow-sm shadow-blue-100"
                      : "border-slate-250 bg-white text-slate-500 hover:bg-slate-50"
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  Administrador
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={formLoading}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg shadow-sm shadow-blue-200 transition-all active:scale-[0.98] disabled:opacity-50"
            >
              {formLoading ? "Creando..." : "Crear Cuenta"}
            </button>
          </form>
        </div>

        {/* Users List */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm lg:col-span-2">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-sm">Cuentas Autorizadas</h3>
              <p className="text-xs text-slate-400">Total: {users.length} usuarios registrados</p>
            </div>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-rose-50 border border-rose-100 text-rose-700 rounded-lg text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              <span>{error}</span>
            </div>
          )}

          {loading ? (
            <div className="py-16 text-center">
              <RefreshCw className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-2" />
              <p className="text-xs text-slate-400 font-medium">Cargando lista de usuarios...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    <th className="pb-3">Usuario</th>
                    <th className="pb-3">Rol</th>
                    <th className="pb-3">Creado el</th>
                    <th className="pb-3 text-right">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((user) => (
                    <tr key={user.id} className="group hover:bg-slate-50/50 transition-colors">
                      <td className="py-4">
                        <span className="font-bold text-slate-700">{user.username}</span>
                        {user.username === currentUser.username && (
                          <span className="ml-2 text-[9px] bg-blue-600 text-white font-bold uppercase px-2 py-0.5 rounded-full shadow-sm shadow-blue-100">
                            Tú
                          </span>
                        )}
                      </td>
                      <td className="py-4">
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border ${
                          user.role === "admin"
                            ? "bg-blue-50 text-blue-700 border-blue-200"
                            : "bg-slate-50 text-slate-600 border-slate-100"
                        }`}>
                          {user.role === "admin" ? "Admin" : "Usuario"}
                        </span>
                      </td>
                      <td className="py-4 text-xs font-medium text-slate-400 font-mono">
                        {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "Sistema"}
                      </td>
                      <td className="py-4 text-right">
                        {user.username !== "Frida29" && (
                          <button
                            onClick={() => handleDeleteUserClick(user.id, user.username)}
                            className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 border border-transparent hover:border-rose-100 rounded-lg transition-colors inline-flex"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Delete User Custom Confirmation Modal */}
      {deleteUserConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full shadow-xl overflow-hidden p-6 space-y-4 animate-fade-in">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center shrink-0">
                <Trash2 className="w-6 h-6 text-rose-600" />
              </div>
              <div className="space-y-1 col-span-3">
                <h3 className="font-extrabold text-slate-800 text-lg">
                  ¿Eliminar Usuario?
                </h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  ¿Está seguro de que desea eliminar permanentemente la cuenta del usuario{" "}
                  <span className="font-bold text-slate-700">"{deleteUserConfirm.username}"</span>? Esta acción no se puede deshacer.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteUserConfirm(null)}
                className="px-4 py-2.5 text-xs font-bold bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg transition-colors shadow-sm"
              >
                Cancelar
              </button>
              <button
                onClick={executeDeleteUser}
                className="px-4 py-2.5 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-lg transition-colors shadow-sm flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                Eliminar Cuenta
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
