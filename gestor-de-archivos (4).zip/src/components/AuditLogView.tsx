import React, { useState } from "react";
import { motion } from "motion/react";
import {
  ShieldAlert,
  User,
  Clock,
  Search,
  LogIn,
  Upload,
  Trash2,
  RefreshCw,
  Edit,
  FolderPlus,
  ArrowRight,
  UserPlus,
  UserMinus
} from "lucide-react";
import { AuditLog } from "../types";

interface AuditLogViewProps {
  logs: AuditLog[];
  onRefresh: () => void;
}

export default function AuditLogView({ logs, onRefresh }: AuditLogViewProps) {
  const [search, setSearch] = useState("");
  const [filterAction, setFilterAction] = useState<string>("all");

  const getActionIcon = (action: string) => {
    switch (action) {
      case "login":
        return <LogIn className="w-4 h-4 text-emerald-600" />;
      case "upload":
        return <Upload className="w-4 h-4 text-blue-600" />;
      case "delete":
        return <Trash2 className="w-4 h-4 text-rose-600" />;
      case "move":
        return <ArrowRight className="w-4 h-4 text-indigo-600" />;
      case "rename":
        return <Edit className="w-4 h-4 text-amber-600" />;
      case "create_folder":
        return <FolderPlus className="w-4 h-4 text-teal-600" />;
      case "restore":
        return <RefreshCw className="w-4 h-4 text-violet-600" />;
      case "create_user":
        return <UserPlus className="w-4 h-4 text-sky-600" />;
      case "delete_user":
        return <UserMinus className="w-4 h-4 text-fuchsia-600" />;
      default:
        return <ShieldAlert className="w-4 h-4 text-gray-600" />;
    }
  };

  const getActionBadgeColor = (action: string) => {
    switch (action) {
      case "login":
        return "bg-emerald-50 text-emerald-700 border-emerald-100";
      case "upload":
        return "bg-blue-50 text-blue-700 border-blue-100";
      case "delete":
        return "bg-rose-50 text-rose-700 border-rose-100";
      case "move":
        return "bg-indigo-50 text-indigo-700 border-indigo-100";
      case "rename":
        return "bg-amber-50 text-amber-700 border-amber-100";
      case "create_folder":
        return "bg-teal-50 text-teal-700 border-teal-100";
      case "restore":
        return "bg-violet-50 text-violet-700 border-violet-100";
      case "create_user":
        return "bg-sky-50 text-sky-700 border-sky-100";
      case "delete_user":
        return "bg-fuchsia-50 text-fuchsia-700 border-fuchsia-100";
      default:
        return "bg-gray-50 text-gray-700 border-gray-100";
    }
  };

  // Human-readable names for actions
  const getActionLabel = (action: string) => {
    switch (action) {
      case "login":
        return "Inicio Sesión";
      case "upload":
        return "Subida";
      case "delete":
        return "Papelera";
      case "move":
        return "Movimiento";
      case "rename":
        return "Renombre";
      case "create_folder":
        return "Nueva Carpeta";
      case "restore":
        return "Restauración";
      case "create_user":
        return "Nuevo Usuario";
      case "delete_user":
        return "Eliminar Usuario";
      default:
        return "Acción";
    }
  };

  // Format timestamp nicely
  const formatTime = (isoString: string) => {
    const d = new Date(isoString);
    return d.toLocaleString("es-ES", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
  };

  // Filter logs based on search query and action dropdown
  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.username.toLowerCase().includes(search.toLowerCase()) ||
      log.details.toLowerCase().includes(search.toLowerCase());

    const matchesAction = filterAction === "all" || log.action === filterAction;

    return matchesSearch && matchesAction;
  });

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 md:p-8 font-sans bg-slate-50 text-slate-900 selection:bg-blue-600 selection:text-white">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-800">
            Registro de Auditoría
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Historial de operaciones y logs en segundo plano de la aplicación.
          </p>
        </div>
        <button
          onClick={onRefresh}
          className="flex items-center gap-2 text-xs font-semibold bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 py-2 px-4 rounded-lg transition-colors shadow-sm self-start md:self-auto"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Actualizar Historial</span>
        </button>
      </div>

      {/* Filter Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col md:flex-row gap-4 items-center mb-6">
        <div className="relative flex-1 w-full">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
            <Search className="w-5 h-5" />
          </span>
          <input
            type="text"
            placeholder="Buscar por usuario o detalles..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white rounded-lg text-sm transition-all outline-none focus:ring-1 focus:ring-blue-600"
          />
        </div>

        <div className="w-full md:w-56 shrink-0">
          <select
            value={filterAction}
            onChange={(e) => setFilterAction(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white rounded-lg text-sm transition-all outline-none font-semibold text-slate-700 focus:ring-1 focus:ring-blue-600"
          >
            <option value="all">Todas las acciones</option>
            <option value="login">Inicio de Sesión</option>
            <option value="upload">Subidas de Archivos</option>
            <option value="delete">Eliminaciones/Papelera</option>
            <option value="move">Movimientos de Archivos</option>
            <option value="rename">Cambios de Nombres</option>
            <option value="create_folder">Nuevas Carpetas</option>
            <option value="restore">Restauraciones</option>
            <option value="create_user">Creación de Usuarios</option>
            <option value="delete_user">Eliminación de Usuarios</option>
          </select>
        </div>
      </div>

      {/* Audit Timeline */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        {filteredLogs.length > 0 ? (
          <div className="divide-y divide-slate-100">
            {filteredLogs.map((log) => (
              <div key={log.id} className="p-4 md:p-6 hover:bg-slate-50/50 transition-colors flex items-start gap-4 animate-fade-in">
                {/* Visual Action Indicator */}
                <div className="w-9 h-9 rounded-lg border border-slate-200 flex items-center justify-center shrink-0 shadow-sm bg-white">
                  {getActionIcon(log.action)}
                </div>

                <div className="flex-1 min-w-0 space-y-1.5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-sm text-slate-850 flex items-center gap-1.5 bg-slate-100 px-2.5 py-1 rounded-full">
                        <User className="w-3.5 h-3.5 text-slate-500" />
                        {log.username}
                      </span>
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 border rounded-full ${getActionBadgeColor(log.action)}`}>
                        {getActionLabel(log.action)}
                      </span>
                    </div>
                    <span className="text-xs text-slate-400 font-medium flex items-center gap-1 shrink-0 font-mono">
                      <Clock className="w-3.5 h-3.5" />
                      {formatTime(log.timestamp)}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed font-medium">
                    {log.details}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-16 text-center animate-fade-in">
            <ShieldAlert className="w-16 h-16 text-slate-300 stroke-[1.5] mx-auto mb-4" />
            <h4 className="font-bold text-slate-600 text-base">Sin resultados en la auditoría</h4>
            <p className="text-xs text-slate-400 mt-1">
              No se encontraron logs que coincidan con la búsqueda o filtro seleccionado.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
