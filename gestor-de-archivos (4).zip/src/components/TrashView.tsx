import React, { useState } from "react";
import { motion } from "motion/react";
import {
  Trash2,
  RefreshCw,
  Folder,
  File,
  FileSpreadsheet,
  FileVideo,
  FileImage,
  FileAudio,
  Calendar,
  User,
  AlertCircle
} from "lucide-react";
import { FolderMetadata, FileMetadata, User as UserType } from "../types";
import { safeJson } from "../utils";

interface TrashViewProps {
  currentUser: UserType;
  folders: FolderMetadata[];
  files: FileMetadata[];
  onRefresh: () => void;
}

export default function TrashView({ currentUser, folders, files, onRefresh }: TrashViewProps) {
  const [actionConfirm, setActionConfirm] = useState<{ type: "folder" | "file"; id: string; name: string; actionType: "restore" | "permanent" } | null>(null);

  // Filter folders and files that are soft-deleted
  const deletedFolders = folders.filter((f) => f.isDeleted);
  const deletedFiles = files.filter((f) => f.isDeleted);

  // Helper to get file icon
  const getFileIcon = (mimeType: string) => {
    const mime = mimeType.toLowerCase();
    if (mime.includes("presentation") || mime.includes("powerpoint") || mime.includes("pptx") || mime.includes("ppt")) {
      return <FileSpreadsheet className="w-8 h-8 text-amber-600" />;
    }
    if (mime.includes("image")) {
      return <FileImage className="w-8 h-8 text-emerald-600" />;
    }
    if (mime.includes("video")) {
      return <FileVideo className="w-8 h-8 text-indigo-600" />;
    }
    if (mime.includes("audio") || mime.includes("mp3") || mime.includes("wav")) {
      return <FileAudio className="w-8 h-8 text-violet-600" />;
    }
    return <File className="w-8 h-8 text-gray-500" />;
  };

  // Format file size
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  // Format date
  const formatDate = (isoString?: string) => {
    if (!isoString) return "Desconocido";
    const d = new Date(isoString);
    return d.toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  // Restore Element Trigger
  const handleRestoreClick = (type: "folder" | "file", id: string, name: string) => {
    setActionConfirm({ type, id, name, actionType: "restore" });
  };

  // Permanent Delete Element Trigger
  const handlePermanentDeleteClick = (type: "folder" | "file", id: string, name: string) => {
    setActionConfirm({ type, id, name, actionType: "permanent" });
  };

  const executeAction = async () => {
    if (!actionConfirm) return;
    const { type, id, actionType } = actionConfirm;
    setActionConfirm(null);

    try {
      if (actionType === "restore") {
        const res = await fetch("/api/drive/restore", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            itemType: type,
            itemId: id,
            username: currentUser.username,
          }),
        });

        if (!res.ok) {
          const data = await safeJson(res);
          throw new Error(data.error || "No se pudo restaurar el elemento.");
        }
      } else {
        const res = await fetch("/api/drive/permanent-delete", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            itemType: type,
            itemId: id,
            username: currentUser.username,
          }),
        });

        if (!res.ok) {
          const data = await safeJson(res);
          throw new Error(data.error || "Error al eliminar permanentemente.");
        }
      }

      onRefresh();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const hasItems = deletedFolders.length > 0 || deletedFiles.length > 0;

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 md:p-8 font-sans bg-slate-50 text-slate-900 selection:bg-blue-600 selection:text-white">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold tracking-tight text-slate-800">
          Papelera de Reciclaje
        </h2>
        <p className="text-sm text-slate-500 mt-1">
          Elementos eliminados recientemente. Aquí se retienen antes de la eliminación física definitiva.
        </p>
      </div>

      {hasItems && (
        <div className="mb-6 p-4 bg-amber-50 border border-amber-100 rounded-lg flex items-start gap-3 text-amber-800 text-xs font-semibold">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <span>
            Los elementos eliminados permanentemente se borrarán del disco local de forma definitiva y liberarán almacenamiento. No podrán recuperarse una vez hecho esto.
          </span>
        </div>
      )}

      {hasItems ? (
        <div className="space-y-6">
          {/* Deleted Folders */}
          {deletedFolders.length > 0 && (
            <div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                Directorios en Papelera
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {deletedFolders.map((f) => (
                  <div
                    key={f.id}
                    className="bg-white border border-slate-200 hover:border-slate-300 rounded-lg p-4 flex items-center justify-between hover:shadow-md transition-all animate-fade-in"
                  >
                    <div className="flex items-center gap-4 min-w-0 flex-1">
                      <Folder className="w-8 h-8 text-slate-400 shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-slate-700 text-sm truncate" title={f.name}>
                          {f.name}
                        </p>
                        <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 font-medium flex-wrap">
                          <span className="flex items-center gap-1">
                            <User className="w-3.5 h-3.5" /> Eliminó: {f.deletedBy || "Desconocido"}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" /> {formatDate(f.deletedAt)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 ml-4">
                      <button
                        onClick={() => handleRestoreClick("folder", f.id, f.name)}
                        className="p-2 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-bold"
                        title="Restaurar carpeta"
                      >
                        <RefreshCw className="w-4 h-4" />
                        <span className="hidden sm:inline">Restaurar</span>
                      </button>
                      <button
                        onClick={() => handlePermanentDeleteClick("folder", f.id, f.name)}
                        className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-bold"
                        title="Eliminar permanentemente"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span className="hidden sm:inline">Eliminar</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Deleted Files */}
          {deletedFiles.length > 0 && (
            <div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                Archivos en Papelera
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {deletedFiles.map((file) => (
                  <div
                    key={file.id}
                    className="bg-white border border-slate-200 hover:border-slate-300 rounded-lg p-4 flex items-center justify-between hover:shadow-md transition-all animate-fade-in"
                  >
                    <div className="flex items-center gap-4 min-w-0 flex-1">
                      {getFileIcon(file.mimeType)}
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-slate-700 text-sm truncate" title={file.name}>
                          {file.name}
                        </p>
                        <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 font-medium flex-wrap">
                          <span>{formatFileSize(file.size)}</span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <User className="w-3.5 h-3.5" /> {file.deletedBy || "Desconocido"}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" /> {formatDate(file.deletedAt)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 ml-4">
                      <button
                        onClick={() => handleRestoreClick("file", file.id, file.name)}
                        className="p-2 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-bold"
                        title="Restaurar archivo"
                      >
                        <RefreshCw className="w-4 h-4" />
                        <span className="hidden sm:inline">Restaurar</span>
                      </button>
                      <button
                        onClick={() => handlePermanentDeleteClick("file", file.id, file.name)}
                        className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-bold"
                        title="Eliminar permanentemente"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span className="hidden sm:inline">Eliminar</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Empty Trash Indicator */
        <div className="flex flex-col items-center justify-center py-20 text-center animate-fade-in">
          <Trash2 className="w-16 h-16 text-slate-300 stroke-[1.5] mb-4" />
          <h4 className="font-bold text-slate-600 text-base">La papelera está vacía</h4>
          <p className="text-xs text-slate-400 mt-1">
            Los elementos que envíe a la Papelera aparecerán aquí para restaurarse o eliminarse definitivamente.
          </p>
        </div>
      )}
      {/* Custom Confirmation Modal Overlay */}
      {actionConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full shadow-xl overflow-hidden p-6 space-y-4 animate-fade-in">
            <div className="flex items-start gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${actionConfirm.actionType === "permanent" ? "bg-rose-50 border border-rose-100" : "bg-blue-50 border border-blue-100"}`}>
                {actionConfirm.actionType === "permanent" ? (
                  <Trash2 className="w-6 h-6 text-rose-600" />
                ) : (
                  <RefreshCw className="w-6 h-6 text-blue-600" />
                )}
              </div>
              <div className="space-y-1 col-span-3">
                <h3 className="font-extrabold text-slate-800 text-lg">
                  {actionConfirm.actionType === "permanent" ? "Eliminar Permanentemente" : "Restaurar Elemento"}
                </h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  {actionConfirm.actionType === "permanent" ? (
                    <>
                      ¡ATENCIÓN! ¿Está seguro de que desea eliminar <span className="font-bold text-slate-700">PERMANENTEMENTE</span> "{actionConfirm.name}"? Esta acción borrará el archivo físico del disco y no se puede deshacer.
                    </>
                  ) : (
                    <>
                      ¿Desea restaurar el elemento <span className="font-bold text-slate-700">"{actionConfirm.name}"</span> a su ubicación original en el Drive?
                    </>
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setActionConfirm(null)}
                className="px-4 py-2.5 text-xs font-bold bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg transition-colors shadow-sm"
              >
                Cancelar
              </button>
              <button
                onClick={executeAction}
                className={`px-4 py-2.5 text-xs font-bold text-white rounded-lg transition-colors shadow-sm flex items-center gap-1.5 ${actionConfirm.actionType === "permanent" ? "bg-rose-600 hover:bg-rose-700" : "bg-blue-600 hover:bg-blue-700"}`}
              >
                {actionConfirm.actionType === "permanent" ? (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Eliminar Físico
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4" />
                    Restaurar Elemento
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
