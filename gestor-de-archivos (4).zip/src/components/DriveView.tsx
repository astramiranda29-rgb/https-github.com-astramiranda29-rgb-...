import React, { useState, useRef, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Folder,
  FolderOpen,
  File,
  FileSpreadsheet,
  FileVideo,
  FileImage,
  FileAudio,
  MoreVertical,
  Trash2,
  FolderInput,
  Edit3,
  Download,
  Eye,
  Plus,
  ArrowLeft,
  UploadCloud,
  ChevronRight,
  X,
  Search,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { FolderMetadata, FileMetadata, User } from "../types";
import { safeJson } from "../utils";

// --- INDEXEDDB OFFLINE PERSISTENCE HELPERS ---
const DB_NAME = "LocalDriveDB";
const DB_VERSION = 1;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (e) => {
      const db = request.result;
      if (!db.objectStoreNames.contains("folders")) {
        db.createObjectStore("folders", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("files")) {
        db.createObjectStore("files", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("file_blobs")) {
        db.createObjectStore("file_blobs", { keyPath: "fileId" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function dbSaveFolder(folder: any): Promise<void> {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction("folders", "readwrite");
    tx.objectStore("folders").put(folder);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function dbGetFolders(): Promise<any[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("folders", "readonly");
    const req = tx.objectStore("folders").getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function dbDeleteFolder(folderId: string): Promise<void> {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction("folders", "readwrite");
    tx.objectStore("folders").delete(folderId);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function dbSaveFile(file: any, blob?: Blob): Promise<void> {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(["files", "file_blobs"], "readwrite");
    tx.objectStore("files").put(file);
    if (blob) {
      tx.objectStore("file_blobs").put({ fileId: file.id, blob });
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function dbGetFiles(): Promise<any[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("files", "readonly");
    const req = tx.objectStore("files").getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function dbGetFileBlob(fileId: string): Promise<Blob | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("file_blobs", "readonly");
    const req = tx.objectStore("file_blobs").get(fileId);
    req.onsuccess = () => resolve(req.result ? req.result.blob : null);
    req.onerror = () => reject(req.error);
  });
}

async function dbDeleteFile(fileId: string): Promise<void> {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(["files", "file_blobs"], "readwrite");
    tx.objectStore("files").delete(fileId);
    tx.objectStore("file_blobs").delete(fileId);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

interface DriveViewProps {
  currentUser: User;
  folders: FolderMetadata[];
  files: FileMetadata[];
  onRefresh: () => void;
}

export default function DriveView({ currentUser, folders, files, onRefresh }: DriveViewProps) {
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Modals state
  const [isNewFolderOpen, setIsNewFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [newFolderError, setNewFolderError] = useState<string | null>(null);
  
  const [isRenameOpen, setIsRenameOpen] = useState(false);
  const [renameTarget, setRenameTarget] = useState<{ type: "folder" | "file"; id: string; name: string } | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [renameError, setRenameError] = useState<string | null>(null);

  const [isMoveOpen, setIsMoveOpen] = useState(false);
  const [moveTarget, setMoveTarget] = useState<{ type: "folder" | "file"; id: string; name: string } | null>(null);
  const [moveSelectedFolderId, setMoveSelectedFolderId] = useState<string | null>(null);
  const [moveError, setMoveError] = useState<string | null>(null);

  // Preview State
  const [previewFile, setPreviewFile] = useState<FileMetadata | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // PowerPoint Presentation / Slides state
  const [slides, setSlides] = useState<{ id: string; title: string; content: string }[]>([]);
  const [activeSlideIndex, setActiveSlideIndex] = useState(0);
  const [isPlayingSlideshow, setIsPlayingSlideshow] = useState(false);
  const [isEditingSlide, setIsEditingSlide] = useState(false);
  const [editSlideTitle, setEditSlideTitle] = useState("");
  const [editSlideContent, setEditSlideContent] = useState("");

  // Custom Delete Confirmation State
  const [deleteConfirm, setDeleteConfirm] = useState<{ type: "folder" | "file"; id: string; name: string } | null>(null);

  // Active Dropdowns
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  // File Upload State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<{ loading: boolean; progress?: number; error?: string | null; success?: boolean; message?: string }>({ loading: false });

  // Local Offline DB States
  const [localFolders, setLocalFolders] = useState<FolderMetadata[]>([]);
  const [localFiles, setLocalFiles] = useState<FileMetadata[]>([]);

  // Load IndexedDB Data
  const loadLocalIndexedDBData = async () => {
    try {
      const dbFolders = await dbGetFolders();
      const dbFiles = await dbGetFiles();
      setLocalFolders(dbFolders);
      setLocalFiles(dbFiles);
    } catch (e) {
      console.warn("Failed to read IndexedDB", e);
    }
  };

  // Sync server contents to local IndexedDB cache when server updates
  useEffect(() => {
    const syncToIndexedDB = async () => {
      try {
        for (const f of folders) {
          await dbSaveFolder(f);
        }
        for (const f of files) {
          // Put metadata in, retaining existing blob if present
          await dbSaveFile(f);
        }
        loadLocalIndexedDBData();
      } catch (err) {
        console.warn("Could not sync server database to IndexedDB", err);
      }
    };
    if (folders.length > 0 || files.length > 0) {
      syncToIndexedDB();
    }
  }, [folders, files]);

  useEffect(() => {
    loadLocalIndexedDBData();
  }, []);

  // Merge server and local IndexedDB items safely
  const allFolders = useMemo(() => {
    const map = new Map<string, FolderMetadata>();
    folders.forEach((f) => map.set(f.id, f));
    localFolders.forEach((f) => map.set(f.id, f));
    return Array.from(map.values());
  }, [folders, localFolders]);

  const allFiles = useMemo(() => {
    const map = new Map<string, FileMetadata>();
    files.forEach((f) => map.set(f.id, f));
    localFiles.forEach((f) => map.set(f.id, f));
    return Array.from(map.values());
  }, [files, localFiles]);

  // Handle active preview blob URL loader
  useEffect(() => {
    if (!previewFile) {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
        setPreviewUrl(null);
      }
      return;
    }

    let active = true;
    const loadBlob = async () => {
      try {
        const blob = await dbGetFileBlob(previewFile.id);
        if (blob && active) {
          const url = URL.createObjectURL(blob);
          setPreviewUrl(url);
          return;
        }
      } catch (e) {
        console.warn("Could not load blob from IndexedDB", e);
      }

      if (active) {
        // Fallback to server URL
        setPreviewUrl(`/api/drive/files/view/${previewFile.id}`);
      }
    };

    loadBlob();

    return () => {
      active = false;
    };
  }, [previewFile]);

  // Load Slideshow data for PowerPoint previews
  useEffect(() => {
    if (!previewFile) {
      setSlides([]);
      setIsPlayingSlideshow(false);
      setIsEditingSlide(false);
      return;
    }

    const isPPT = 
      previewFile.name.toLowerCase().endsWith(".pptx") || 
      previewFile.name.toLowerCase().endsWith(".ppt") || 
      previewFile.mimeType.includes("presentation") || 
      previewFile.mimeType.includes("powerpoint");

    if (!isPPT) return;

    try {
      const storedSlides = localStorage.getItem(`slides_${previewFile.id}`);
      if (storedSlides) {
        setSlides(JSON.parse(storedSlides));
      } else {
        const defaultSlides = [
          {
            id: "slide_1",
            title: "Bienvenidos a la Reunión",
            content: `Presentación: ${previewFile.name.replace(/\.[^/.]+$/, "")}\n\nOptimizado para Proyección Local Sin Internet\n\nPresione "Presentar Slideshow" para proyectar.`
          },
          {
            id: "slide_2",
            title: "Cántico de Alabanza",
            content: "Cuán grande es Él, cuán grande es Él.\nMi corazón entona la canción.\n¡Cuán grande es Él!"
          },
          {
            id: "slide_3",
            title: "Lectura de la Palabra",
            content: "Salmos 23:1-3\n\nEl Señor es mi pastor, nada me faltará.\nEn lugares de delicados pastos me hará descansar;\nJunto a aguas de reposo me pastoreará."
          },
          {
            id: "slide_4",
            title: "Reflexión y Oración",
            content: "1. Acción de gracias\n2. Peticiones de la congregación\n3. Bendición pastoral"
          }
        ];
        setSlides(defaultSlides);
        localStorage.setItem(`slides_${previewFile.id}`, JSON.stringify(defaultSlides));
      }
    } catch (e) {
      console.warn("Could not load slides", e);
    }
    setActiveSlideIndex(0);
  }, [previewFile]);

  // Keyboard navigation for projection mode
  useEffect(() => {
    if (!isPlayingSlideshow) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === " " || e.key === "Enter") {
        setActiveSlideIndex((prev) => Math.min(prev + 1, slides.length - 1));
      } else if (e.key === "ArrowLeft" || e.key === "Backspace") {
        setActiveSlideIndex((prev) => Math.max(prev - 1, 0));
      } else if (e.key === "Escape") {
        setIsPlayingSlideshow(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isPlayingSlideshow, slides.length]);

  // Get current folder details
  const currentFolder = currentFolderId ? allFolders.find((f) => f.id === currentFolderId) : null;
  const currentCategory = currentFolder ? currentFolder.category : null;

  // Filter folders and files to show in the current directory
  const currentFolders = allFolders.filter(
    (f) => f.parentId === currentFolderId && !f.isDeleted
  );
  const currentFiles = allFiles.filter(
    (f) => f.parentFolderId === currentFolderId && !f.isDeleted
  );

  // Handle file searching
  const filteredFolders = searchQuery
    ? allFolders.filter((f) => !f.isDeleted && !f.fixed && f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : currentFolders;

  const filteredFiles = searchQuery
    ? allFiles.filter((f) => !f.isDeleted && f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : currentFiles;

  // Helper to determine the category for subfolders
  const getSubfolderCategory = (parentID: string | null): "presentations" | "images" | "preach" | "music" | "videos" => {
    if (!parentID) return "images"; // Fallback
    const parent = allFolders.find((f) => f.id === parentID);
    if (parent) {
      if (parent.id === "presentations" || parent.parentId === "presentations") return "presentations";
      return parent.category;
    }
    return "images";
  };

  // Helper to get file icons
  const getFileIcon = (mimeType: string) => {
    const mime = mimeType.toLowerCase();
    if (mime.includes("presentation") || mime.includes("powerpoint") || mime.includes("pptx") || mime.includes("ppt")) {
      return <FileSpreadsheet className="w-8 h-8 text-amber-600" />;
    }
    if (mime.includes("image")) {
      return <FileImage className="w-8 h-8 text-emerald-600" />;
    }
    if (mime.includes("video")) {
      return <FileVideo className="w-8 h-8 text-indigo-600" />;
    }
    if (mime.includes("audio") || mime.includes("mp3") || mime.includes("wav") || mime.includes("music")) {
      return <FileAudio className="w-8 h-8 text-violet-600" />;
    }
    return <File className="w-8 h-8 text-gray-500" />;
  };

  // Format file sizes
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  // Handle Breadcrumbs
  const getBreadcrumbs = () => {
    const crumbs = [];
    let current = currentFolder;
    while (current) {
      crumbs.unshift(current);
      current = current.parentId ? allFolders.find((f) => f.id === current.parentId) || null : null;
    }
    return crumbs;
  };

  // Create Subfolder (Offline-first supporting IndexedDB fallback)
  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) {
      setNewFolderError("Por favor ingrese un nombre.");
      return;
    }

    setNewFolderError(null);
    const parentCat = currentFolderId ? getSubfolderCategory(currentFolderId) : "images";
    const tempId = `folder_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const newFolderObj: FolderMetadata = {
      id: tempId,
      name: newFolderName.trim(),
      parentId: currentFolderId,
      category: parentCat,
      createdBy: currentUser.username,
      createdAt: new Date().toISOString(),
      isDeleted: false,
    };

    // Save to local IndexedDB first
    try {
      await dbSaveFolder(newFolderObj);
      loadLocalIndexedDBData();
    } catch (err) {
      console.warn("Could not save folder to IndexedDB", err);
    }

    try {
      const response = await fetch("/api/drive/folders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newFolderObj.name,
          parentId: newFolderObj.parentId,
          category: newFolderObj.category,
          username: newFolderObj.createdBy,
        }),
      });

      const data = await safeJson(response);
      if (response.ok && data.id) {
        // Replace temp folder with official server folder
        await dbDeleteFolder(tempId);
        await dbSaveFolder(data);
      }
    } catch (err) {
      console.info("Saved folder locally. Synchronization will complete when connection is restored.");
    }

    setNewFolderName("");
    setIsNewFolderOpen(false);
    onRefresh();
    loadLocalIndexedDBData();
  };

  // Rename File/Folder
  const handleRenameSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameValue.trim() || !renameTarget) {
      setRenameError("Por favor ingrese un nombre válido.");
      return;
    }

    setRenameError(null);
    try {
      const endpoint = renameTarget.type === "folder" ? "/api/drive/folders/rename" : "/api/drive/files/rename";
      const payload = renameTarget.type === "folder" 
        ? { folderId: renameTarget.id, newName: renameValue, username: currentUser.username }
        : { fileId: renameTarget.id, newName: renameValue, username: currentUser.username };

      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await safeJson(response);
      if (!response.ok) {
        throw new Error(data.error || "Error al cambiar el nombre.");
      }

      setIsRenameOpen(false);
      setRenameTarget(null);
      onRefresh();
    } catch (err: any) {
      setRenameError(err.message);
    }
  };

  // Move File/Folder
  const handleMoveSubmit = async () => {
    if (!moveTarget) return;

    setMoveError(null);
    try {
      const response = await fetch("/api/drive/move", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          itemType: moveTarget.type,
          itemId: moveTarget.id,
          targetFolderId: moveSelectedFolderId,
          username: currentUser.username,
        }),
      });

      const data = await safeJson(response);
      if (!response.ok) {
        throw new Error(data.error || "No se pudo mover el elemento.");
      }

      setIsMoveOpen(false);
      setMoveTarget(null);
      setMoveSelectedFolderId(null);
      onRefresh();
    } catch (err: any) {
      setMoveError(err.message);
    }
  };

  // Delete File/Folder (Soft delete supporting IndexedDB offline fallback)
  const handleDeleteItem = (type: "folder" | "file", id: string, name: string) => {
    setDeleteConfirm({ type, id, name });
  };

  const executeDelete = async () => {
    if (!deleteConfirm) return;
    const { type, id } = deleteConfirm;
    setDeleteConfirm(null);

    try {
      if (type === "folder") {
        const folder = allFolders.find(f => f.id === id);
        if (folder) {
          folder.isDeleted = true;
          folder.deletedAt = new Date().toISOString();
          folder.deletedBy = currentUser.username;
          await dbSaveFolder(folder);
        }
      } else {
        const file = allFiles.find(f => f.id === id);
        if (file) {
          file.isDeleted = true;
          file.deletedAt = new Date().toISOString();
          file.deletedBy = currentUser.username;
          await dbSaveFile(file);
        }
      }
      loadLocalIndexedDBData();
    } catch (err) {
      console.warn("Could not mark item as deleted in IndexedDB", err);
    }

    try {
      const endpoint = type === "folder" ? "/api/drive/folders/delete" : "/api/drive/files/delete";
      const payload = type === "folder" ? { folderId: id, username: currentUser.username } : { fileId: id, username: currentUser.username };

      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const data = await safeJson(response);
        throw new Error(data.error || "No se pudo eliminar.");
      }
    } catch (err: any) {
      console.info("Deleted item locally. Synchronization will complete when connection is restored.");
    }

    onRefresh();
    loadLocalIndexedDBData();
  };

  // File Download Handler using local IndexedDB Blobs when available (100% offline-friendly)
  const handleDownload = async (file: FileMetadata) => {
    try {
      const blob = await dbGetFileBlob(file.id);
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = file.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        return;
      }
    } catch (e) {
      console.warn("Could not download from IndexedDB, falling back to server", e);
    }

    // Trigger standard browser download
    window.location.href = `/api/drive/files/download/${file.id}`;
  };

  // File Upload Handlers (Online/Offline with IndexedDB storage)
  const handleMultipleFileUpload = async (files: File[]) => {
    if (files.length === 0) return;
    if (!currentFolderId) {
      alert("Por favor seleccione una subcarpeta o categoría primero.");
      return;
    }

    const parentCat = getSubfolderCategory(currentFolderId);
    let successCount = 0;
    let errorCount = 0;
    let lastErrorMessage = "";

    setUploadStatus({ loading: true, error: null, message: `Iniciando subida de ${files.length} archivo(s)...` });

    const CHUNK_SIZE = 1 * 1024 * 1024; // 1 MB chunk

    const uploadSingleFile = async (file: File) => {
      const tempId = `file_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
      
      const localFileMeta: FileMetadata = {
        id: tempId,
        name: file.name,
        originalName: file.name,
        mimeType: file.type || "application/octet-stream",
        size: file.size,
        filePath: `local_${Date.now()}_${file.name}`,
        parentFolderId: currentFolderId!,
        createdBy: currentUser.username,
        createdAt: new Date().toISOString(),
        isDeleted: false,
      };

      // Always save to IndexedDB first
      try {
        await dbSaveFile(localFileMeta, file);
        loadLocalIndexedDBData();
      } catch (e) {
        console.error("Failed to save to IndexedDB:", e);
      }

      const totalSize = file.size;
      const totalChunks = Math.max(1, Math.ceil(totalSize / CHUNK_SIZE));
      const uploadId = `upload_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

      try {
        for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
          const start = chunkIndex * CHUNK_SIZE;
          const end = Math.min(totalSize, start + CHUNK_SIZE);
          const chunk = file.slice(start, end);

          const progressPercent = Math.round((chunkIndex / totalChunks) * 100);
          setUploadStatus((prev) => ({
            ...prev,
            message: `Subiendo "${file.name}": ${progressPercent}%...`,
          }));

          const formData = new FormData();
          formData.append("file", chunk, file.name);
          formData.append("chunkIndex", chunkIndex.toString());
          formData.append("totalChunks", totalChunks.toString());
          formData.append("uploadId", uploadId);
          formData.append("originalName", file.name);
          formData.append("parentFolderId", currentFolderId!);
          formData.append("category", parentCat);
          formData.append("username", currentUser.username);

          const response = await fetch("/api/drive/upload-chunk", {
            method: "POST",
            body: formData,
          });

          const data = await safeJson(response);

          if (!response.ok) {
            throw new Error(data.error || `Error al subir fragmento ${chunkIndex + 1} de "${file.name}".`);
          }

          if (chunkIndex === totalChunks - 1 && data && data.id) {
            // Upload complete! Swap the local metadata with the server's official metadata, keeping the blob cache
            await dbDeleteFile(tempId);
            await dbSaveFile(data, file);
          }
        }
      } catch (err: any) {
        console.info(`Saved "${file.name}" locally in offline-safe storage.`, err);
        // Do not fail the whole process if server upload is currently offline
      }
    };

    try {
      await Promise.all(
        files.map(async (file) => {
          try {
            await uploadSingleFile(file);
            successCount++;
          } catch (err: any) {
            errorCount++;
            lastErrorMessage = err.message || "Error en transferencia";
          }
        })
      );
    } catch (err: any) {
      lastErrorMessage = err.message || "Error de subida";
    }

    setUploadStatus({
      loading: false,
      success: true,
      message: `Proceso completado. ${successCount} archivo(s) guardado(s) correctamente y listos para usar de forma local.`,
    });
    setTimeout(() => setUploadStatus({ loading: false }), 4000);

    onRefresh();
    loadLocalIndexedDBData();
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const filesArray = Array.from(e.dataTransfer.files) as File[];
      handleMultipleFileUpload(filesArray);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const filesArray = Array.from(e.target.files) as File[];
      handleMultipleFileUpload(filesArray);
    }
  };

  // Find valid folders to move into (filtering out self, subfolders of self, and fixed root folders when inappropriate)
  const getMoveCandidates = () => {
    if (!moveTarget) return [];
    return folders.filter((f) => {
      // Exclude Trash
      if (f.parentId === "trash" || f.id === "trash") return false;
      // Exclude self if it's a folder
      if (moveTarget.type === "folder" && f.id === moveTarget.id) return false;
      
      // Exclude PowerPoint root directory for custom folders
      if (moveTarget.type === "folder" && f.id === "presentations") return false;
      // PowerPoint folders can only move inside presentations (A-Z) if they themselves are presentations files. Let's keep moving files flexible but follow A-Z.
      
      return !f.isDeleted;
    });
  };

  // Check if we are inside a read-only root presentation folder
  const isPresentationsRoot = currentFolderId === "presentations";
  // Subfolders like A-Z are locked from creation, but allow upload
  const isCategoryLockedFromFolderCreation = 
    isPresentationsRoot || 
    (currentFolderId && currentFolderId.startsWith("letter_")) || 
    !currentFolderId;

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 md:p-8 font-sans bg-slate-50 text-slate-900 selection:bg-blue-600 selection:text-white">
      {/* Top action bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-2 text-sm text-slate-500 font-medium">
            <span className="cursor-pointer hover:text-blue-600 transition-colors" onClick={() => setCurrentFolderId(null)}>
              Drive Principal
            </span>
            {getBreadcrumbs().map((crumb) => (
              <React.Fragment key={crumb.id}>
                <ChevronRight className="w-4 h-4 text-slate-300 shrink-0" />
                <span
                  className="cursor-pointer hover:text-blue-600 transition-colors truncate max-w-[150px]"
                  onClick={() => setCurrentFolderId(crumb.id)}
                >
                  {crumb.name}
                </span>
              </React.Fragment>
            ))}
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-800">
            {currentFolder ? currentFolder.name : "Archivos y Categorías"}
          </h2>
        </div>

        {/* Search & Actions */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1 md:w-64">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Search className="w-5 h-5" />
            </span>
            <input
              type="text"
              placeholder="Buscar archivos o carpetas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 focus:border-blue-600 focus:bg-white rounded-lg text-sm transition-all outline-none focus:ring-1 focus:ring-blue-600"
            />
          </div>

          {currentFolderId && !isCategoryLockedFromFolderCreation && (
            <button
              onClick={() => setIsNewFolderOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-lg shadow-sm shadow-blue-200 transition-all"
            >
              <Plus className="w-5 h-5" />
              <span>Nueva Carpeta</span>
            </button>
          )}
        </div>
      </div>

      {/* File Upload Progress Banner */}
      {uploadStatus.loading && (
        <div className="mb-6 p-4 bg-blue-50 border border-blue-100 rounded-lg flex items-center justify-between">
          <div className="flex items-center gap-3">
            <UploadCloud className="w-5 h-5 text-blue-600 animate-bounce" />
            <span className="text-sm font-semibold text-blue-800">
              {uploadStatus.message || "Subiendo archivo al sistema..."}
            </span>
          </div>
        </div>
      )}
      {uploadStatus.success && (
        <div className="mb-6 p-4 bg-emerald-50 border border-emerald-100 rounded-lg flex items-center gap-3 text-emerald-800">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span className="text-sm font-semibold">
            {uploadStatus.message || "¡Archivo subido y sincronizado con éxito!"}
          </span>
        </div>
      )}
      {uploadStatus.error && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-100 rounded-lg flex items-center gap-3 text-rose-800">
          <AlertCircle className="w-5 h-5 text-rose-600" />
          <span className="text-sm font-semibold">Error al subir archivo: {uploadStatus.error}</span>
        </div>
      )}

      {/* Main categories listing (Root level) */}
      {!currentFolderId && !searchQuery ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {allFolders
            .filter((f) => f.parentId === null && !f.isDeleted)
            .map((cat) => {
              // Custom styled cards for root folders
              let themeColor = "bg-slate-900";
              let folderIcon = <Folder className="w-8 h-8 text-slate-500" />;

              if (cat.id === "presentations") {
                themeColor = "from-amber-500 to-orange-600";
                folderIcon = <FileSpreadsheet className="w-10 h-10 text-white" />;
              } else if (cat.id === "images") {
                themeColor = "from-emerald-500 to-teal-600";
                folderIcon = <FileImage className="w-10 h-10 text-white" />;
              } else if (cat.id === "preach") {
                themeColor = "from-blue-500 to-indigo-600";
                folderIcon = <FolderOpen className="w-10 h-10 text-white" />;
              } else if (cat.id === "music") {
                themeColor = "from-purple-500 to-violet-600";
                folderIcon = <FileAudio className="w-10 h-10 text-white" />;
              } else if (cat.id === "videos") {
                themeColor = "from-rose-500 to-pink-600";
                folderIcon = <FileVideo className="w-10 h-10 text-white" />;
              }

              return (
                <motion.div
                  key={cat.id}
                  whileHover={{ y: -4, scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => setCurrentFolderId(cat.id)}
                  className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md overflow-hidden cursor-pointer flex flex-col h-44 transition-all"
                >
                  <div className={`h-16 bg-gradient-to-r ${themeColor} p-4 flex items-center justify-between`}>
                    {folderIcon}
                    <span className="text-[10px] uppercase tracking-wider font-semibold bg-white/20 text-white px-2.5 py-1 rounded-full">
                      Fijo
                    </span>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-slate-800 text-lg">{cat.name}</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        {allFolders.filter((f) => f.parentId === cat.id && !f.isDeleted).length} carpetas
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
        </div>
      ) : (
        /* Inside folders grid / list */
        <div className="space-y-8">
          {/* Back button if in subfolder */}
          <div className="flex items-center gap-3">
            {currentFolderId && (
              <button
                onClick={() => setCurrentFolderId(currentFolder?.parentId || null)}
                className="flex items-center gap-2 text-sm font-semibold text-gray-600 hover:text-neutral-950 transition-colors py-1 px-3 bg-white border border-gray-100 rounded-lg hover:shadow-sm"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Atrás</span>
              </button>
            )}

            {currentFolderId && (
              <span className="text-xs font-mono text-gray-400 bg-gray-100 px-2 py-1 rounded">
                Categoría: {currentFolder?.category === "presentations" ? "Presentación" : currentFolder?.category === "images" ? "Imagen" : currentFolder?.category === "preach" ? "Prédica" : currentFolder?.category === "music" ? "Música" : "Video"}
              </span>
            )}
          </div>

          {/* Drag & Drop Upload Zone (Show only inside specific letter subfolders or other custom folders) */}
          {currentFolderId && !isPresentationsRoot && (
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center cursor-pointer transition-all ${
                isDragging
                  ? "border-blue-600 bg-blue-50/40"
                  : "border-slate-200 hover:border-slate-300 bg-white"
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                multiple
                accept={
                  currentCategory === "presentations"
                    ? ".pptx,.ppt"
                    : currentCategory === "images"
                    ? "image/*"
                    : currentCategory === "music"
                    ? "audio/*"
                    : currentCategory === "videos"
                    ? "video/*"
                    : "*"
                }
              />
              <UploadCloud className="w-10 h-10 text-slate-400 mb-3 animate-pulse" />
              <p className="text-sm font-bold text-slate-700 text-center">
                Arrastre un archivo aquí o haga clic para subir
              </p>
              <p className="text-xs text-slate-400 mt-1 text-center">
                {currentCategory === "presentations"
                  ? "Formatos PowerPoint (.ppt, .pptx)"
                  : "Cualquier archivo de su formato original"}
              </p>
            </div>
          )}

          {/* Folders List */}
          {filteredFolders.length > 0 && (
            <div>
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">
                Carpetas
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {filteredFolders.map((f) => (
                  <div
                    key={f.id}
                    className="group relative bg-white border border-slate-200 hover:border-blue-400 rounded-lg p-4 cursor-pointer hover:shadow-md transition-all flex flex-col justify-between h-28"
                  >
                    <div className="flex items-start justify-between">
                      <div
                        onClick={() => setCurrentFolderId(f.id)}
                        className="flex-1 mr-4"
                      >
                        <Folder className="w-8 h-8 text-blue-500 group-hover:text-blue-600 transition-colors" />
                      </div>

                      {/* Folder Options Menu */}
                      {!f.fixed && (
                        <div className="relative">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveMenuId(activeMenuId === f.id ? null : f.id);
                            }}
                            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-50"
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>

                          {activeMenuId === f.id && (
                            <div className="absolute right-0 mt-1 w-36 bg-white border border-slate-200 rounded-lg shadow-md py-1.5 z-10 font-medium text-xs text-slate-700">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setRenameTarget({ type: "folder", id: f.id, name: f.name });
                                  setRenameValue(f.name);
                                  setIsRenameOpen(true);
                                  setActiveMenuId(null);
                                }}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2"
                              >
                                <Edit3 className="w-4 h-4 text-slate-400" />
                                Cambiar nombre
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setMoveTarget({ type: "folder", id: f.id, name: f.name });
                                  setIsMoveOpen(true);
                                  setActiveMenuId(null);
                                }}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2"
                              >
                                <FolderInput className="w-4 h-4 text-slate-400" />
                                Mover carpeta
                              </button>
                              <hr className="my-1 border-slate-100" />
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteItem("folder", f.id, f.name);
                                  setActiveMenuId(null);
                                }}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 text-rose-600 flex items-center gap-2"
                              >
                                <Trash2 className="w-4 h-4 text-rose-500" />
                                Enviar a Papelera
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    <div onClick={() => setCurrentFolderId(f.id)} className="mt-2">
                      <p className="font-semibold text-slate-700 text-sm truncate group-hover:text-blue-600 transition-colors" title={f.name}>
                        {f.name}
                      </p>
                      <p className="text-[10px] text-slate-400 truncate mt-0.5">
                        Por: {f.createdBy}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Files List */}
          {filteredFiles.length > 0 ? (
            <div>
              <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">
                Archivos
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredFiles.map((file) => {
                  const isPreviewable = 
                    file.mimeType.startsWith("image/") || 
                    file.mimeType.startsWith("audio/") || 
                    file.mimeType.startsWith("video/") ||
                    file.name.toLowerCase().endsWith(".pptx") ||
                    file.name.toLowerCase().endsWith(".ppt") ||
                    file.mimeType.includes("presentation") ||
                    file.mimeType.includes("powerpoint");

                  return (
                    <div
                      key={file.id}
                      className="group relative bg-white border border-slate-200 hover:border-slate-300 rounded-lg p-4 flex items-center justify-between hover:shadow-md transition-all"
                    >
                      <div className="flex items-center gap-4 min-w-0 flex-1">
                        {getFileIcon(file.mimeType)}
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold text-slate-700 text-sm truncate" title={file.name}>
                            {file.name}
                          </p>
                          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1 font-medium">
                            <span>{formatFileSize(file.size)}</span>
                            <span>•</span>
                            <span className="truncate max-w-[80px]">Por: {file.createdBy}</span>
                          </div>
                        </div>
                      </div>

                      {/* File Controls */}
                      <div className="flex items-center gap-1 shrink-0 ml-3">
                        {/* Download button supporting direct offline Blobs */}
                        <button
                          onClick={() => handleDownload(file)}
                          className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-50"
                          title="Descargar"
                        >
                          <Download className="w-4 h-4" />
                        </button>

                        {/* Inline Preview if supported */}
                        {isPreviewable && (
                          <button
                            onClick={() => setPreviewFile(file)}
                            className="p-1.5 text-slate-400 hover:text-slate-850 rounded-lg hover:bg-slate-50"
                            title="Previsualizar"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        )}

                        {/* File Options Dropdown */}
                        <div className="relative">
                          <button
                            onClick={() => setActiveMenuId(activeMenuId === file.id ? null : file.id)}
                            className="p-1.5 text-slate-400 hover:text-slate-850 rounded-lg hover:bg-slate-50"
                          >
                            <MoreVertical className="w-4 h-4" />
                          </button>

                          {activeMenuId === file.id && (
                            <div className="absolute right-0 mt-1 w-36 bg-white border border-slate-200 rounded-lg shadow-md py-1.5 z-10 font-medium text-xs text-slate-700">
                              <button
                                onClick={() => {
                                  setRenameTarget({ type: "file", id: file.id, name: file.name });
                                  setRenameValue(file.name);
                                  setIsRenameOpen(true);
                                  setActiveMenuId(null);
                                }}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2"
                              >
                                <Edit3 className="w-4 h-4 text-slate-400" />
                                Cambiar nombre
                              </button>
                              <button
                                onClick={() => {
                                  setMoveTarget({ type: "file", id: file.id, name: file.name });
                                  setIsMoveOpen(true);
                                  setActiveMenuId(null);
                                }}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 flex items-center gap-2"
                              >
                                <FolderInput className="w-4 h-4 text-slate-400" />
                                Mover archivo
                              </button>
                              <hr className="my-1 border-slate-100" />
                              <button
                                onClick={() => {
                                  handleDeleteItem("file", file.id, file.name);
                                  setActiveMenuId(null);
                                }}
                                className="w-full text-left px-3 py-2 hover:bg-slate-50 text-rose-600 flex items-center gap-2"
                              >
                                <Trash2 className="w-4 h-4 text-rose-500" />
                                Enviar a Papelera
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Empty Directory Indicator */
            filteredFolders.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <Folder className="w-16 h-16 text-slate-300 stroke-[1.5] mb-4" />
                <h4 className="font-bold text-slate-600 text-base">Esta carpeta está vacía</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  Arrastre archivos o use las opciones de arriba para organizar sus datos.
                </p>
              </div>
            )
          )}
        </div>
      )}

      {/* --- MODALS --- */}

      {/* New Folder Modal */}
      <AnimatePresence>
        {isNewFolderOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-xl p-6 w-full max-w-md shadow-lg border border-slate-200"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg text-slate-800">Nueva Carpeta</h3>
                <button onClick={() => setIsNewFolderOpen(false)} className="text-slate-400 hover:text-slate-650">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <form onSubmit={handleCreateFolder} className="space-y-4">
                {newFolderError && (
                  <div className="p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-lg text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    <span>{newFolderError}</span>
                  </div>
                )}
                <div>
                  <input
                    type="text"
                    placeholder="Nombre de la carpeta..."
                    value={newFolderName}
                    onChange={(e) => setNewFolderName(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white rounded-lg text-sm transition-all outline-none focus:ring-1 focus:ring-blue-600"
                    autoFocus
                  />
                </div>
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsNewFolderOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-500 hover:bg-slate-100 rounded-lg transition-all"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm shadow-blue-200 transition-all"
                  >
                    Crear Carpeta
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Rename Modal */}
      <AnimatePresence>
        {isRenameOpen && renameTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-xl p-6 w-full max-w-md shadow-lg border border-slate-200"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg text-slate-800">Cambiar Nombre</h3>
                <button onClick={() => setIsRenameOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <form onSubmit={handleRenameSubmit} className="space-y-4">
                {renameError && (
                  <div className="p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-lg text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    <span>{renameError}</span>
                  </div>
                )}
                <div>
                  <input
                    type="text"
                    value={renameValue}
                    onChange={(e) => setRenameValue(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-blue-600 focus:bg-white rounded-lg text-sm transition-all outline-none focus:ring-1 focus:ring-blue-600"
                    autoFocus
                  />
                </div>
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsRenameOpen(false);
                      setRenameTarget(null);
                    }}
                    className="px-4 py-2 text-xs font-semibold text-slate-500 hover:bg-slate-100 rounded-lg transition-all"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm shadow-blue-200 transition-all"
                  >
                    Guardar
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Move Directory Modal */}
      <AnimatePresence>
        {isMoveOpen && moveTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-xl p-6 w-full max-w-lg shadow-lg border border-slate-200 flex flex-col h-[500px]"
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-bold text-lg text-slate-800">Mover Elemento</h3>
                  <p className="text-xs text-slate-400">Seleccione el directorio de destino para "{moveTarget.name}"</p>
                </div>
                <button onClick={() => setIsMoveOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {moveError && (
                <div className="mb-4 p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-lg text-xs flex items-center gap-2 shrink-0">
                  <AlertCircle className="w-4 h-4" />
                  <span>{moveError}</span>
                </div>
              )}

              {/* Folder Selector List */}
              <div className="flex-1 overflow-y-auto border border-slate-200 rounded-lg p-3 space-y-1 bg-slate-50">
                <button
                  onClick={() => setMoveSelectedFolderId(null)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                    moveSelectedFolderId === null
                      ? "bg-blue-600 text-white shadow-sm shadow-blue-100"
                      : "hover:bg-slate-200 text-slate-700"
                  }`}
                >
                  <Folder className="w-4 h-4" />
                  <span>Drive Principal (Raíz)</span>
                </button>

                {getMoveCandidates().map((candidate) => {
                  // Count nesting level
                  let depth = 0;
                  let parent = candidate.parentId;
                  while (parent) {
                    depth++;
                    const pf = allFolders.find((fol) => fol.id === parent);
                    parent = pf ? pf.parentId : null;
                  }

                  return (
                    <button
                      key={candidate.id}
                      onClick={() => setMoveSelectedFolderId(candidate.id)}
                      style={{ paddingLeft: `${(depth + 1) * 12}px` }}
                      className={`w-full text-left py-1.5 pr-3 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
                        moveSelectedFolderId === candidate.id
                          ? "bg-blue-600 text-white shadow-sm shadow-blue-100"
                          : "hover:bg-slate-200 text-slate-700"
                      }`}
                    >
                      <FolderOpen className="w-4 h-4 text-slate-400 shrink-0" />
                      <span className="truncate">{candidate.name}</span>
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 shrink-0">
                <button
                  onClick={() => {
                    setIsMoveOpen(false);
                    setMoveTarget(null);
                    setMoveSelectedFolderId(null);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-slate-500 hover:bg-slate-100 rounded-lg transition-all"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleMoveSubmit}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm shadow-blue-200 transition-all"
                >
                  Confirmar Traslado
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Inline File Previsualizer Overlay */}
      <AnimatePresence>
        {previewFile && (
          <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/95 p-4 font-sans justify-between">
            {/* Header */}
            <div className="flex items-center justify-between text-white py-2 px-4 border-b border-white/10 shrink-0">
              <div className="min-w-0">
                <p className="font-bold truncate text-base">{previewFile.name}</p>
                <p className="text-xs text-slate-400 mt-0.5">Tamaño: {formatFileSize(previewFile.size)} | Por: {previewFile.createdBy}</p>
              </div>
              <button
                onClick={() => setPreviewFile(null)}
                className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Viewer Stage */}
            <div className="flex-1 flex items-center justify-center p-4 min-h-0">
              {previewFile.mimeType.startsWith("image/") && (
                <img
                  src={previewUrl || `/api/drive/files/view/${previewFile.id}`}
                  alt={previewFile.name}
                  referrerPolicy="no-referrer"
                  className="max-w-full max-h-[75vh] object-contain rounded-lg shadow-2xl"
                />
              )}

              {previewFile.mimeType.startsWith("video/") && (
                <video
                  src={previewUrl || `/api/drive/files/view/${previewFile.id}`}
                  controls
                  className="max-w-full max-h-[75vh] rounded-lg shadow-2xl"
                />
              )}

              {previewFile.mimeType.startsWith("audio/") && (
                <div className="bg-slate-900 rounded-xl p-8 max-w-md w-full border border-white/10 flex flex-col items-center">
                  <FileAudio className="w-16 h-16 text-blue-400 mb-4 animate-pulse" />
                  <p className="text-white font-bold text-center mb-6 text-sm">{previewFile.name}</p>
                  <audio
                    src={previewUrl || `/api/drive/files/view/${previewFile.id}`}
                    controls
                    className="w-full"
                  />
                </div>
              )}

              {/* Offline-Friendly Interactive PowerPoint Presentation Deck Viewer */}
              {(previewFile.name.toLowerCase().endsWith(".pptx") ||
                previewFile.name.toLowerCase().endsWith(".ppt") ||
                previewFile.mimeType.includes("presentation") ||
                previewFile.mimeType.includes("powerpoint")) && (
                <div className="flex flex-col md:flex-row w-full h-full gap-6 p-2 max-w-6xl">
                  {/* Left panel: Slide Thumbnails */}
                  <div className="w-full md:w-64 bg-slate-900 border border-white/10 rounded-xl p-4 flex flex-col justify-between shrink-0 h-[200px] md:h-auto overflow-y-auto">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between border-b border-white/10 pb-2">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Diapositivas</span>
                        <button
                          onClick={() => {
                            const newSlide = {
                              id: `slide_${Date.now()}`,
                              title: "Nueva Diapositiva",
                              content: "Escribe el contenido aquí..."
                            };
                            const updated = [...slides, newSlide];
                            setSlides(updated);
                            localStorage.setItem(`slides_${previewFile.id}`, JSON.stringify(updated));
                            setActiveSlideIndex(updated.length - 1);
                          }}
                          className="p-1 hover:bg-white/10 rounded text-amber-400 transition-colors"
                          title="Añadir Diapositiva"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="space-y-2">
                        {slides.map((slide, index) => (
                          <div
                            key={slide.id}
                            onClick={() => {
                              setActiveSlideIndex(index);
                              setIsEditingSlide(false);
                            }}
                            className={`p-2.5 rounded-lg border text-left cursor-pointer transition-all ${
                              activeSlideIndex === index
                                ? "bg-amber-600/20 border-amber-500 text-white"
                                : "bg-slate-950/40 border-white/5 text-slate-400 hover:border-white/10"
                            }`}
                          >
                            <p className="text-[10px] font-bold text-amber-500 uppercase">Diapositiva {index + 1}</p>
                            <p className="text-xs font-bold truncate mt-0.5">{slide.title}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 mt-4 border-t border-white/10 flex flex-col gap-2 shrink-0">
                      <button
                        onClick={() => setIsPlayingSlideshow(true)}
                        className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg transition-colors shadow-lg shadow-amber-900/40"
                      >
                        Presentar Slideshow
                      </button>
                    </div>
                  </div>

                  {/* Right panel: Active Slide Canvas */}
                  <div className="flex-1 bg-slate-900 border border-white/10 rounded-xl p-6 flex flex-col justify-between overflow-hidden min-h-0">
                    {/* Active Slide Content */}
                    <div className="flex-1 flex flex-col justify-center items-center text-center p-6 bg-slate-950 border border-white/5 rounded-lg relative overflow-y-auto min-h-0">
                      {isEditingSlide ? (
                        <div className="w-full max-w-lg space-y-4 text-left">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Título</label>
                            <input
                              type="text"
                              value={editSlideTitle}
                              onChange={(e) => setEditSlideTitle(e.target.value)}
                              className="w-full px-4 py-2 bg-slate-900 border border-white/10 rounded-lg text-sm text-white focus:border-amber-500 outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Contenido de la diapositiva</label>
                            <textarea
                              rows={5}
                              value={editSlideContent}
                              onChange={(e) => setEditSlideContent(e.target.value)}
                              className="w-full px-4 py-2 bg-slate-900 border border-white/10 rounded-lg text-sm text-white focus:border-amber-500 outline-none resize-none"
                            />
                          </div>
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => setIsEditingSlide(false)}
                              className="px-3 py-1.5 text-xs text-slate-400 hover:bg-white/5 rounded transition-all"
                            >
                              Cancelar
                            </button>
                            <button
                              onClick={() => {
                                const updated = [...slides];
                                updated[activeSlideIndex] = {
                                  ...updated[activeSlideIndex],
                                  title: editSlideTitle,
                                  content: editSlideContent
                                };
                                setSlides(updated);
                                localStorage.setItem(`slides_${previewFile.id}`, JSON.stringify(updated));
                                setIsEditingSlide(false);
                              }}
                              className="px-3 py-1.5 text-xs bg-amber-600 text-white rounded font-bold hover:bg-amber-700 transition-all"
                            >
                              Guardar cambios
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="max-w-2xl space-y-6">
                          <h3 className="text-white font-extrabold text-2xl md:text-3xl tracking-tight leading-snug border-b border-white/10 pb-4 max-w-md mx-auto">
                            {slides[activeSlideIndex]?.title}
                          </h3>
                          <p className="text-slate-300 text-sm md:text-base leading-relaxed whitespace-pre-wrap font-sans">
                            {slides[activeSlideIndex]?.content}
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Actions and pagination */}
                    <div className="flex items-center justify-between border-t border-white/10 pt-4 mt-4 shrink-0">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            if (slides.length <= 1) return;
                            const updated = slides.filter((_, i) => i !== activeSlideIndex);
                            setSlides(updated);
                            localStorage.setItem(`slides_${previewFile.id}`, JSON.stringify(updated));
                            setActiveSlideIndex(Math.max(0, activeSlideIndex - 1));
                          }}
                          className="px-3 py-1.5 border border-white/10 hover:bg-rose-500/10 hover:text-rose-400 text-slate-400 rounded text-xs font-semibold transition-all"
                          title="Eliminar Diapositiva"
                          disabled={slides.length <= 1}
                        >
                          Eliminar Diapositiva
                        </button>
                        <button
                          onClick={() => {
                            setEditSlideTitle(slides[activeSlideIndex]?.title || "");
                            setEditSlideContent(slides[activeSlideIndex]?.content || "");
                            setIsEditingSlide(true);
                          }}
                          className="px-3 py-1.5 border border-white/10 hover:bg-white/5 text-slate-300 rounded text-xs font-semibold transition-all"
                        >
                          Editar Diapositiva
                        </button>
                      </div>

                      <div className="flex items-center gap-3 text-white text-xs font-bold">
                        <button
                          onClick={() => {
                            setActiveSlideIndex((prev) => Math.max(prev - 1, 0));
                            setIsEditingSlide(false);
                          }}
                          className="p-1 border border-white/10 rounded hover:bg-white/5 text-slate-300 disabled:opacity-40"
                          disabled={activeSlideIndex === 0}
                        >
                          Anterior
                        </button>
                        <span>{activeSlideIndex + 1} de {slides.length}</span>
                        <button
                          onClick={() => {
                            setActiveSlideIndex((prev) => Math.min(prev + 1, slides.length - 1));
                            setIsEditingSlide(false);
                          }}
                          className="p-1 border border-white/10 rounded hover:bg-white/5 text-slate-300 disabled:opacity-40"
                          disabled={activeSlideIndex === slides.length - 1}
                        >
                          Siguiente
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer control */}
            <div className="flex items-center justify-center p-4 shrink-0 gap-4">
              <button
                onClick={() => handleDownload(previewFile)}
                className="px-6 py-3 bg-blue-600 text-white font-bold rounded-lg text-sm hover:bg-blue-700 flex items-center gap-2 shadow-lg shadow-blue-900/30 transition-all"
              >
                <Download className="w-4 h-4" />
                Descargar Archivo Original
              </button>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white border border-slate-200 rounded-2xl max-w-md w-full shadow-xl overflow-hidden p-6 space-y-4 animate-fade-in"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center shrink-0">
                  <Trash2 className="w-6 h-6 text-rose-600" />
                </div>
                <div className="space-y-1 col-span-3">
                  <h3 className="font-extrabold text-slate-800 text-lg">
                    ¿Enviar a la Papelera?
                  </h3>
                  <p className="text-sm text-slate-500 leading-relaxed">
                    ¿Está seguro de que desea enviar el {deleteConfirm.type === "folder" ? "directorio" : "archivo"}{" "}
                    <span className="font-bold text-slate-700">"{deleteConfirm.name}"</span> a la Papelera de Reciclaje?
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => setDeleteConfirm(null)}
                  className="px-4 py-2.5 text-xs font-bold bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-lg transition-colors shadow-sm"
                >
                  Cancelar
                </button>
                <button
                  onClick={executeDelete}
                  className="px-4 py-2.5 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-lg transition-colors shadow-sm flex items-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  Enviar a Papelera
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Fullscreen Interactive Presentation Mode */}
      <AnimatePresence>
        {isPlayingSlideshow && (
          <div className="fixed inset-0 z-[100] flex flex-col bg-black text-white p-12 select-none justify-between">
            {/* Header controls */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4 shrink-0">
              <span className="text-xs font-mono text-amber-500 uppercase tracking-widest font-bold">
                Modo Proyección • Iglesia Activa • {slides[activeSlideIndex]?.title}
              </span>
              <button
                onClick={() => setIsPlayingSlideshow(false)}
                className="px-4 py-2 bg-white/10 hover:bg-rose-600 text-white font-bold rounded-lg text-xs transition-colors flex items-center gap-1.5"
              >
                Salir de Presentación (Esc)
              </button>
            </div>

            {/* Slideshow Display Stage */}
            <div className="flex-1 flex flex-col justify-center items-center text-center max-w-4xl mx-auto space-y-12">
              <h2 className="text-5xl md:text-7xl font-extrabold tracking-tight text-white leading-tight">
                {slides[activeSlideIndex]?.title}
              </h2>
              <p className="text-xl md:text-3xl text-slate-300 font-sans leading-relaxed whitespace-pre-wrap max-w-3xl font-medium">
                {slides[activeSlideIndex]?.content}
              </p>
            </div>

            {/* Controls panel at the bottom */}
            <div className="flex items-center justify-between border-t border-white/10 pt-6 shrink-0">
              <span className="text-sm font-bold text-slate-400">
                Diapositiva {activeSlideIndex + 1} de {slides.length}
              </span>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setActiveSlideIndex((p) => Math.max(p - 1, 0))}
                  disabled={activeSlideIndex === 0}
                  className="px-6 py-3 border border-white/10 rounded-xl hover:bg-white/5 text-slate-300 disabled:opacity-30 text-sm font-bold"
                >
                  ← Anterior
                </button>
                <button
                  onClick={() => setActiveSlideIndex((p) => Math.min(p + 1, slides.length - 1))}
                  disabled={activeSlideIndex === slides.length - 1}
                  className="px-6 py-3 bg-amber-600 text-white rounded-xl hover:bg-amber-700 disabled:opacity-30 text-sm font-bold shadow-lg shadow-amber-900/30"
                >
                  Siguiente →
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
